package DataAccess;

public interface DatabaseInfo {
    public static String DRIVERNAME="com.microsoft.sqlserver.jdbc.SQLServerDriver";
    public static String DBURL="jdbc:sqlserver://justduck;databaseName=DoAnDatabase;encrypt=false;trustServerCertificate=false;loginTimeout=30";
    public static String USERDB="sa";
    public static String PASSDB="123";
}

//DESKTOP-EQJSVSA : Thien
//ADMIN-PC\SQLEXPRESS : TNTD
//justduck : Duc
